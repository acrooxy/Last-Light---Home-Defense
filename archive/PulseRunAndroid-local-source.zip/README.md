# Last Light — Android

A portrait arcade survival game built with Java and Android Canvas. Protect a modern safehouse from distinct animated zombie types in a larger, scrolling garden.

## Gameplay

- Explore a larger backyard; the camera follows the survivor and the fence is farther from the house.
- Defend the home through 60-second rounds. Zombie health rises gradually each round, with different strengths for runners, brutes, and bloated zombies.
- Move the survivor with the virtual stick; the rifle automatically aims and fires at nearby zombies. The survivor has a separate health meter from the house.
- Dropped crystals automatically home toward the survivor. Level-up bonuses and the shop's Crystal Magnet increase pickup range and pull speed.
- Spend credits between rounds on faster fire, stronger rounds, faster movement, home reinforcement, or the crystal magnet.

## Visuals and performance

- Bright garden colors, flower details, distant timber fencing, and a contemporary safehouse.
- Larger human survivor and humanoid zombie silhouettes, drawn with custom Canvas art.
- The static garden and fence are cached as a bitmap instead of being redrawn every frame. Text typefaces are reused to reduce allocations during gameplay.

## Controls

- Hold and drag the virtual stick in the lower-left corner to move.
- Tap **DASH** in the lower-right corner to dodge.
- Tap the pause control at the top-right to pause.
- Tap one of the level-up cards, or buy upgrades between rounds.

## Run

Open this folder in Android Studio, wait for Gradle sync, then run the `app` configuration on an emulator or a connected Android phone.

`PulseRunAndroid.apk` is a debug build. The project compiles with Android SDK 37, targets SDK 36, and stores the best score locally.
